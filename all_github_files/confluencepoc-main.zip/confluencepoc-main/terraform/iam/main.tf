terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  backend "s3" {
    bucket = "conf-poc-bucket-eas"
    key    = "test/state.tfstate"
    region = "us-east-1"
  }
}

provider "aws" {
  region = "us-east-1"
}

data "aws_caller_identity" "current" {}


resource "aws_iam_role" "lb_controller" {
  name = "AmazonEKS_EBS_CSI_DriverRole2"

  # Updated assume_role_policy (trust relationship) for IRSA with hardcoded OIDC for testing
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRoleWithWebIdentity"
        Effect = "Allow"
        Principal = {
          Federated = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:oidc-provider/oidc.eks.us-east-1.amazonaws.com/id/F7881459342ABE8F21558A466591E34D"
        }
        Condition = {
          StringEquals = {
            "oidc.eks.us-east-1.amazonaws.com/id/F7881459342ABE8F21558A466591E34D:sub" = "system:serviceaccount:kube-system:aws-load-balancer-controller"
            "oidc.eks.us-east-1.amazonaws.com/id/F7881459342ABE8F21558A466591E34D:aud" = "sts.amazonaws.com"
          }
        }
      }
    ]
  })
}