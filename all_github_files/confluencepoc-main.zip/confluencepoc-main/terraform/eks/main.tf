terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.0"
    }
  }

  backend "s3" {
    bucket = "conf-poc-bucket-eas"
    key    = "eks-efs-test/state.tfstate"
    region = "us-east-1"
  }
}

provider "aws" {
  region = "us-east-1"
}

# EKS Cluster with API Server Authentication
resource "aws_eks_cluster" "my_cluster" {
  name                      = "poc-cluster"
  role_arn                  = "arn:aws:iam::976193262802:role/EKSClusterRole" # Replace with your existing role ARN
  
  # Enable API server authentication with access config
  access_config {
    authentication_mode                        = "API"
    bootstrap_cluster_creator_admin_permissions = true
  }

  vpc_config {
    endpoint_public_access    = true    # Public endpoint access
    endpoint_private_access   = true    # Private endpoint access
    subnet_ids = [
      "subnet-0d88863f447def082", # Replace with your subnet IDs
      "subnet-07e9bb7d782ee0d85"  # Replace with your subnet IDs
    ]
  }

  # Enable cluster logging (optional, adjust as needed)
  enabled_cluster_log_types = ["api", "audit", "authenticator", "controllerManager", "scheduler"]
}

# EKS Node Group
resource "aws_eks_node_group" "my_node_group" {
  cluster_name    = aws_eks_cluster.my_cluster.name
  node_group_name = "poc-node-group"
  node_role_arn   = "arn:aws:iam::976193262802:role/EKSNodeGroupRole" # Replace with your existing role ARN
  subnet_ids      = [
    "subnet-07e9bb7d782ee0d85", # Replace with your subnet IDs
    "subnet-0d88863f447def082"  # Replace with your subnet IDs
  ]

  scaling_config {
    desired_size = 2
    max_size     = 2
    min_size     = 2
  }

  instance_types = ["m5.2xlarge"]
  depends_on = [aws_eks_cluster.my_cluster]
}

# Data sources for dynamic trust policy (OIDC issuer from your EKS cluster)
data "aws_caller_identity" "current" {}

data "aws_eks_cluster" "cluster" {
  name = aws_eks_cluster.my_cluster.name  # Reference the created cluster
}

# Extract the OIDC issuer URL (e.g., oidc.eks.us-east-1.amazonaws.com/id/ABC123)
data "tls_certificate" "cluster_oidc" {
  url = data.aws_eks_cluster.cluster.identity[0].oidc[0].issuer
}

# Create OIDC Provider for IRSA
resource "aws_iam_openid_connect_provider" "eks_oidc" {
  client_id_list  = ["sts.amazonaws.com"]  # Audience for STS tokens
  thumbprint_list = [data.tls_certificate.cluster_oidc.certificates[0].sha1_fingerprint]  # Root CA thumbprint
  url             = data.aws_eks_cluster.cluster.identity[0].oidc[0].issuer  # e.g., https://oidc.eks.us-east-1.amazonaws.com/id/ABC123

  # Tags for organization
  tags = {
    Name        = "EKS-OIDC-${data.aws_eks_cluster.cluster.name}"
    Environment = "poc"
  }

  depends_on = [aws_eks_cluster.my_cluster]  # Ensures cluster (and OIDC) is enabled
}

# Imported existing role with updated trust policy (fixed name mismatch; assuming for Load Balancer Controller based on policy)
resource "aws_iam_role" "efs_controller" {
  name = "AmazonEKS_EFS_CSI_DriverRole2"  # Fixed: Match the policy for aws-load-balancer-controller

  # Updated assume_role_policy (trust relationship) for IRSA
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRoleWithWebIdentity"
        Effect = "Allow"
        Principal = {
          Federated = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:oidc-provider/${replace(data.aws_eks_cluster.cluster.identity[0].oidc[0].issuer, "https://", "")}"
        }
        Condition = {
          StringEquals = {
            "${replace(data.aws_eks_cluster.cluster.identity[0].oidc[0].issuer, "https://", "")}:sub" = "system:system:serviceaccount:kube-system:efs-csi-*"
            "${replace(data.aws_eks_cluster.cluster.identity[0].oidc[0].issuer, "https://", "")}:aud" = "sts.amazonaws.com"
          }
        }
      }
    ]
  })

  depends_on = [aws_iam_openid_connect_provider.eks_oidc]  # Ensures OIDC provider exists
}

resource "aws_iam_role" "lb_controller" {
  name = "AmazonEKSLoadBalancerControllerRole2"  # Fixed: Match the policy for aws-load-balancer-controller

  # Updated assume_role_policy (trust relationship) for IRSA
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRoleWithWebIdentity"
        Effect = "Allow"
        Principal = {
          Federated = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:oidc-provider/${replace(data.aws_eks_cluster.cluster.identity[0].oidc[0].issuer, "https://", "")}"
        }
        Condition = {
          StringEquals = {
            "${replace(data.aws_eks_cluster.cluster.identity[0].oidc[0].issuer, "https://", "")}:sub" = "system:serviceaccount:kube-system:aws-load-balancer-controller"
            "${replace(data.aws_eks_cluster.cluster.identity[0].oidc[0].issuer, "https://", "")}:aud" = "sts.amazonaws.com"
          }
        }
      }
    ]
  })

  depends_on = [aws_iam_openid_connect_provider.eks_oidc]  # Ensures OIDC provider exists
}

# EFS File System (mirroring the attachment: us-east-1, tagged with Name=efs-cluster-new)
resource "aws_efs_file_system" "cluster_efs" {
  creation_token   = "eks-cluster-efs-token"
  performance_mode = "generalPurpose"
  throughput_mode  = "bursting"
  encrypted        = true

  tags = {
    Name        = "efs-cluster-eks"
    Environment = "poc"
  }

  depends_on = [aws_eks_cluster.my_cluster]
}

# EFS Mount Targets (one per subnet for EKS node access)
resource "aws_efs_mount_target" "cluster_efs_mt_a" {
  file_system_id  = aws_efs_file_system.cluster_efs.id
  subnet_id       = "subnet-0d88863f447def082"  # Matching EKS subnet
  security_groups = ["sg-0a6b5e8b547e24fcc"]  # Optionally specify a security group allowing NFS (2049) from nodes

  depends_on = [aws_efs_file_system.cluster_efs]  # Explicit for clarity
}

resource "aws_efs_mount_target" "cluster_efs_mt_b" {
  file_system_id  = aws_efs_file_system.cluster_efs.id
  subnet_id       = "subnet-07e9bb7d782ee0d85"  # Matching EKS subnet
  security_groups = ["sg-0a6b5e8b547e24fcc"]  # Optionally specify a security group allowing NFS (2049) from nodes

  depends_on = [aws_efs_file_system.cluster_efs]  # Explicit for clarity
}

# EFS Access Point (mirroring attachment: root path /confluence-shared, POSIX user/group 2002, permissions 0755)
resource "aws_efs_access_point" "cluster_efs_ap" {
  file_system_id = aws_efs_file_system.cluster_efs.id

  posix_user {
    uid            = 2002
    gid            = 2002
    secondary_gids = []
  }

  root_directory {
    path = "/confluence-shared"
    creation_info {
      owner_uid   = 2002
      owner_gid   = 2002
      permissions = "0755"
    }
  }

  tags = {
    Name        = "efs-cluster-new-access-point"
    Environment = "poc"
  }

  depends_on = [aws_efs_file_system.cluster_efs]
}

# Enable Automatic Backups for EFS (daily, 35-day retention)
resource "aws_efs_backup_policy" "cluster_efs_backup" {
  file_system_id = aws_efs_file_system.cluster_efs.id

  backup_policy {
    status = "ENABLED"
  }

  depends_on = [aws_efs_file_system.cluster_efs]
}