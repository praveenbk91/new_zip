#!/bin/bash

# Usage: ./check-ssm-status.sh <command_id> [instance_id]
# If instance_id not provided, fetches it via tag.

set -e  # Exit on any error

COMMAND_ID="${1}"
INSTANCE_ID="${2}"

if [ -z "$COMMAND_ID" ]; then
  echo "Error: Command ID is required"
  exit 1
fi

if [ -z "$INSTANCE_ID" ]; then
  INSTANCE_ID=$(aws ec2 describe-instances --filters 'Name=tag:Name,Values=poc-confluence-k8s' --query 'Reservations[*].Instances[*].InstanceId' --output text | head -n 1)
  [ -z "$INSTANCE_ID" ] && { echo "Error: No instance found with tag Name=poc-confluence-k8s"; exit 1; }
fi

echo "Checking status for Command ID: $COMMAND_ID on Instance: $INSTANCE_ID"

for ((i=1; i<=60; i++)); do
  STATUS=$(aws ssm get-command-invocation --command-id "$COMMAND_ID" --instance-id "$INSTANCE_ID" --query Status --output text 2>/dev/null || echo Unknown)
  echo "Attempt $i/180: Status $STATUS"
  case $STATUS in
    Success) echo "Command succeeded"; exit 0 ;;
    Failed|Cancelled|TimedOut) echo "Command failed: $STATUS"; exit 1 ;;
  esac
  sleep 10
done

echo "Command timed out: $STATUS"
exit 1