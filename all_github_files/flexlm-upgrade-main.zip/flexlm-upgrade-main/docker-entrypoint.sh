#!/bin/bash

# Check if HOSTID is provided
if [ -z "$HOSTID" ]; then
    echo "ERROR: HOSTID environment variable not set. Please provide it via -e HOSTID=<your_hostid>."
    exit 1
fi

# Update the license file with the container's hostname and provided HOSTID
sed -i "s/^SERVER .*/SERVER ${HOSTNAME} ${HOSTID} 27000/" /opt/qchem/flexnet/etc/qchem.lic
sed -i "/^VENDOR qchemlm/c\VENDOR qchemlm 8090" /opt/qchem/flexnet/etc/qchem.lic

_term () {
    echo "SHUTTING DOWN LMGRD"
    /opt/qchem/flexnet/bin/lmutil lmdown -q -force
    echo "SHUTDOWN LMGRD"
}

trap _term SIGTERM EXIT

echo "STARTUP LMGRD"
/opt/qchem/flexnet/bin/lmgrd -z -2 -p -local -c /opt/qchem/flexnet/etc/qchem.lic -l +/usr/local/flexlm/logs/qchem_lm.log &

child=$!
wait "$child"