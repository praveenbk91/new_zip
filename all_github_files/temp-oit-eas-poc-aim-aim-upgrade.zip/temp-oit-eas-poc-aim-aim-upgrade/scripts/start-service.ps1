$ErrorActionPreference = "Stop"
try {
    if (Get-Service -Name {{NEW_VERSION}} -ErrorAction SilentlyContinue) {
        Write-Output "Starting {{NEW_VERSION}} service"
        Start-Service -Name {{NEW_VERSION}}
        $maxWaitSeconds = 60
        $waitInterval = 5
        $elapsed = 0
        while ($elapsed -lt $maxWaitSeconds -and (Get-Service -Name {{NEW_VERSION}} -ErrorAction SilentlyContinue).Status -ne "Running") {
            Write-Output "Waiting for {{NEW_VERSION}} service to start ($elapsed/$maxWaitSeconds seconds)..."
            Start-Sleep -Seconds $waitInterval
            $elapsed += $waitInterval
        }
        if ((Get-Service -Name {{NEW_VERSION}} -ErrorAction SilentlyContinue).Status -ne "Running") {
            Write-Error "Service {{NEW_VERSION}} failed to start after $maxWaitSeconds seconds"
            exit 1
        } else {
            Write-Output "Service {{NEW_VERSION}} started successfully"
            Write-Output "Service status: $((Get-Service -Name {{NEW_VERSION}} -ErrorAction SilentlyContinue).Status)"
        }
    } else {
        Write-Error "Service {{NEW_VERSION}} not found"
        exit 1
    }
} catch {
    Write-Error "Error starting {{NEW_VERSION}} service: $_"
    exit 1
}