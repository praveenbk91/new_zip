# Create the target directory if it doesn't exist
$targetDir = "C:\{{NEW_VERSION}}\lib"
New-Item -ItemType Directory -Path $targetDir -Force

# Download ojdbc11.jar with the required cookie header
$uri = "https://download.oracle.com/otn-pub/otn_software/jdbc/237/ojdbc11.jar"
$headers = @{ "Cookie" = "oraclelicense=accept-securebackup-cookie" }
$outputPath = "$targetDir\ojdbc11.jar"

Invoke-WebRequest -Uri $uri -Headers $headers -OutFile $outputPath

# Verify the download
if (Test-Path $outputPath) {
    Write-Output "Successfully downloaded ojdbc11.jar to $outputPath"
} else {
    Write-Error "Failed to download ojdbc11.jar"
    exit 1
}