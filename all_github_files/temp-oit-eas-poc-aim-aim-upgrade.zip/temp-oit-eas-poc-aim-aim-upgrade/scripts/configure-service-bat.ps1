$ErrorActionPreference = "Stop"
try {
    if (-not (Test-Path "C:\{{NEW_VERSION}}\bin\service.bat")) {
        Write-Error "service.bat not found at C:\{{NEW_VERSION}}\bin"
        exit 1
    }

    # Read the content
    $content = Get-Content -Path "C:\{{NEW_VERSION}}\bin\service.bat" -Raw

    # Normalize line endings
    $content = $content -replace "`r?`n", "`r`n"

    # Define the new memory value from workflow input
    $newMemory = "{{NEW_MEMORY}}"  # Will be replaced by GitHub Actions with ${{ github.event.inputs.new_memory }}
    if (-not $newMemory -match '^\d+$') {
        Write-Error "Invalid memory value provided: $newMemory. Must be a positive integer."
        exit 1
    }

    # Pattern to match the JvmMs line with any numeric value
    $jvmMsPattern = '(?im)^if\s+"%JvmMs%"\s*==\s*""\s+set\s+JvmMs=\s*(\d+)'
    # Replace with the new memory value
    $newContent = $content -replace $jvmMsPattern, "if ""%JvmMs%"" == """" set JvmMs=$newMemory"
    $jvmMsChanged = ($newContent -ne $content)

    # Pattern to match the JvmMx line with any numeric value
    $jvmMxPattern = '(?im)^if\s+"%JvmMx%"\s*==\s*""\s+set\s+JvmMx=\s*(\d+)'
    # Replace with the new memory value
    $newContent = $newContent -replace $jvmMxPattern, "if ""%JvmMx%"" == """" set JvmMx=$newMemory"
    $jvmMxChanged = ($newContent -ne $content)

    # Define a more flexible pattern for hibernate.dialect
    $pattern = '(?im)^rem\s+"%EXECUTABLE%"\s+//US//%SERVICE_NAME%\s+\+\+JvmOptions="\-Dhibernate\.dialect=org\.hibernate\.dialect\.Oracle10gDialect"'
    $replacement = '"%EXECUTABLE%" //US//%SERVICE_NAME% ++JvmOptions="-Dhibernate.dialect=org.hibernate.dialect.Oracle10gDialect"'
    $newContent = $newContent -replace $pattern, $replacement
    $hibernateChanged = ($newContent -ne $content)

    # Check if at least one replacement occurred
    if (-not ($jvmMsChanged -or $jvmMxChanged -or $hibernateChanged)) {
        Write-Error "No match found for any line to replace in service.bat"
        exit 1
    }

    # Write the updated content back
    Set-Content -Path "C:\{{NEW_VERSION}}\bin\service.bat" -Value $newContent -NoNewline
    Write-Output "Configured service.bat successfully"
} catch {
    Write-Error "Error configuring service.bat: $_"
    exit 1
}