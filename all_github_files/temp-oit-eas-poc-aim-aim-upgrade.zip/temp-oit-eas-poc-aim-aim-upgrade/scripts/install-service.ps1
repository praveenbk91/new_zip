$ErrorActionPreference = "Stop"
try {
    $env:CATALINA_HOME = "C:\{{NEW_VERSION}}"
    $serviceBatPath = "C:\{{NEW_VERSION}}\bin\service.bat"
    if (Test-Path $serviceBatPath) {
        Write-Output "Found service.bat, installing {{NEW_VERSION}} service"
        & $serviceBatPath install
        Start-Sleep -Seconds 5
        if (Get-Service -Name {{NEW_VERSION}} -ErrorAction SilentlyContinue) {
            Write-Output "Setting {{NEW_VERSION}} service to Automatic startup"
            Set-Service -Name {{NEW_VERSION}} -StartupType Automatic
            Write-Output "Granting SYSTEM full control to C:\{{NEW_VERSION}}"
            icacls C:\{{NEW_VERSION}} /grant SYSTEM:F /T /C
            Write-Output "Service {{NEW_VERSION}} installed and configured successfully"
            Write-Output "Service status: $((Get-Service -Name {{NEW_VERSION}} -ErrorAction SilentlyContinue).Status)"
            Write-Output "Service startup type: $((Get-Service -Name {{NEW_VERSION}} -ErrorAction SilentlyContinue).StartType)"
        } else {
            Write-Error "Service {{NEW_VERSION}} not found after installation"
            exit 1
        }
    } else {
        Write-Error "service.bat not found in C:\{{NEW_VERSION}}\bin"
        exit 1
    }
} catch {
    Write-Error "Error installing or configuring {{NEW_VERSION}} service: $_"
    exit 1
}