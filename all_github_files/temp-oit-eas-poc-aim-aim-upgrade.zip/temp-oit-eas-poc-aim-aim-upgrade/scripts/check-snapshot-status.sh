#!/bin/bash
SNAPSHOT_ID=$1
region=$2
[ -z "$SNAPSHOT_ID" ] || [ -z "$region" ] && { echo "Usage: $0 <snapshot_id> <region>"; exit 1; }
echo "Waiting for snapshot $SNAPSHOT_ID to be available..."
TIMEOUT=1800
ELAPSED=0
POLL_INTERVAL=30
while [ $ELAPSED -lt $TIMEOUT ]; do
  STATUS=$(aws rds describe-db-snapshots --db-snapshot-identifier "$SNAPSHOT_ID" --region "$region" --query 'DBSnapshots[0].Status' --output text)
  echo "Snapshot status: $STATUS"
  [ "$STATUS" = "available" ] && { echo "Snapshot $SNAPSHOT_ID is available"; exit 0; }
  [ "$STATUS" = "failed" ] && { echo "Snapshot $SNAPSHOT_ID failed to create"; exit 1; }
  sleep $POLL_INTERVAL
  ELAPSED=$((ELAPSED + POLL_INTERVAL))
done
echo "Timeout waiting for snapshot $SNAPSHOT_ID after $TIMEOUT seconds"
exit 1