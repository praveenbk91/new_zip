# Download the file and capture the exit code
& aws s3 cp s3://aimpoc/{{NEW_VERSION}}.zip C:\{{NEW_VERSION}}.zip --region us-east-1
if ($LASTEXITCODE -ne 0) {
    Write-Error "Failed to download C:\{{NEW_VERSION}}.zip from S3 (AWS CLI error: $LASTEXITCODE)"
    exit 1
}
# Verify the file exists
if (-not (Test-Path C:\{{NEW_VERSION}}.zip)) {
    Write-Error "Failed to download C:\{{NEW_VERSION}}.zip from S3 (file not found)"
    exit 1
}
# Extract the zip
Expand-Archive -Path C:\{{NEW_VERSION}}.zip -DestinationPath C:\ -Force
if (-not (Test-Path C:\{{NEW_VERSION}})) {
    Write-Error "Failed to extract C:\{{NEW_VERSION}}"
    exit 1
} else {
    Write-Output "Extracted C:\{{NEW_VERSION}} successfully"
}