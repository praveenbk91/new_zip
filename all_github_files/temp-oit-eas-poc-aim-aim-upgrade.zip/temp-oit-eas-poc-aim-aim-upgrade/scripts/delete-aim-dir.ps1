Remove-Item -Path C:\{{CURRENT_VERSION}} -Recurse -Force -ErrorAction SilentlyContinue
if (Test-Path C:\{{CURRENT_VERSION}}) {
    Write-Error "Failed to delete C:\{{CURRENT_VERSION}}"
    exit 1
} else {
    Write-Output "Directory C:\{{CURRENT_VERSION}} successfully deleted"
}