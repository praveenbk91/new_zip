$ErrorActionPreference = "Stop"
try {
    $env:CATALINA_HOME = "C:\{{CURRENT_VERSION}}"
    Stop-Service -Name {{CURRENT_VERSION}} -Force -ErrorAction SilentlyContinue
    $maxWaitSeconds = 180
    $waitInterval = 5
    $elapsed = 0
    while ($elapsed -lt $maxWaitSeconds -and (Get-Service -Name {{CURRENT_VERSION}} -ErrorAction SilentlyContinue).Status -eq "Running") {
        Write-Output "Waiting for {{CURRENT_VERSION}} service to stop ($elapsed/$maxWaitSeconds seconds)..."
        Start-Sleep -Seconds $waitInterval
        $elapsed += $waitInterval
    }
    if ((Get-Service -Name {{CURRENT_VERSION}} -ErrorAction SilentlyContinue).Status -eq "Running") {
        Write-Error "Service {{CURRENT_VERSION}} failed to stop after $maxWaitSeconds seconds"
        exit 1
    } else {
        Write-Output "Service {{CURRENT_VERSION}} stopped or not found"
        Write-Output "Service status: $((Get-Service -Name {{CURRENT_VERSION}} -ErrorAction SilentlyContinue).Status)"
    }
    $serviceBatPath = "C:\{{CURRENT_VERSION}}\bin\service.bat"
    if (Test-Path $serviceBatPath) {
        & $serviceBatPath uninstall
        Start-Sleep -Seconds 20
    } else {
        Write-Output "service.bat not found in C:\{{CURRENT_VERSION}}\bin, skipping uninstall"
    }
    sc delete {{CURRENT_VERSION}}
    Start-Sleep -Seconds 5
    $maxProcessChecks = 5
    $checkInterval = 5
    for ($i = 1; $i -le $maxProcessChecks; $i++) {
        Get-CimInstance Win32_Process | Where-Object { $_.Path -like "*{{CURRENT_VERSION}}*" -or $_.Name -like "java*" -or $_.Name -like "tomcat*" -or $_.CommandLine -like "*{{CURRENT_VERSION}}*" } | ForEach-Object {
            Write-Output "Terminating process (check $i/$maxProcessChecks): $($_.Name) (PID: $($_.ProcessId), Path: $($_.Path), CommandLine: $($_.CommandLine))"
            Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
        }
        Start-Sleep -Seconds $checkInterval
    }
    icacls "C:\{{CURRENT_VERSION}}" /grant SYSTEM:F /T /C
    Remove-Item -Path "C:\{{CURRENT_VERSION}}\logs" -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -Path "C:\{{CURRENT_VERSION}}\temp" -Recurse -Force -ErrorAction SilentlyContinue
} catch {
    Write-Error "Error stopping or cleaning up {{CURRENT_VERSION}} service: $_"
    exit 1
}