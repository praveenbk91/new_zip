# Template Info
This repository is based off the EAS modern application template. It includes GitHub Actions workflows for creating and destroying application resources, creating and destroying a container factory, and building and pushing container images to an AWS ECR.

## Container Factory
The container factory is designed to build and push images from a dockfile located in the "containers" directory. It currently supports pushing a single container image to the container registry created by the corresponding terraform workflow. 

## Application Pipeline
The "terraform-deploy-app" workflow will deploy the terraform code located in the "terraform/app-infra" directory. Terraform code must be formatted using "terraform fmt" before being pushed to the repository or the workflow will fail.

## Container Pipeline
The "terraform-deploy-ecr" workflow will deploy the terraform code located in the "terraform/container-infra" directory. Terraform code must be formatted using "terraform fmt" before being pushed to the repository or the workflow will fail.

# temp-oit-eas-poc-aim
The following section contains information relevant to the AiM containerization PoC.
