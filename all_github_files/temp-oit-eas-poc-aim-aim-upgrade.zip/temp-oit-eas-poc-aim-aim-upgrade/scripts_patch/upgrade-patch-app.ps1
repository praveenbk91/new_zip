$ErrorActionPreference = "Stop"
try {
    if (Get-Service -Name {{CURRENT_VERSION}} -ErrorAction SilentlyContinue) {
        Write-Output "Stopping {{CURRENT_VERSION}} service"
        Stop-Service -Name {{CURRENT_VERSION}} -Force -ErrorAction SilentlyContinue
    }
    Write-Output "Removing logs, webapps, and work directories"
    Remove-Item -Path C:\{{CURRENT_VERSION}}\logs\* -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -Path C:\{{CURRENT_VERSION}}\webapps\fmax -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -Path C:\{{CURRENT_VERSION}}\webapps\reportviewer -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -Path C:\{{CURRENT_VERSION}}\work\catalina -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -Path C:\{{CURRENT_VERSION}}\webapps\fmax.war -ErrorAction SilentlyContinue
    Write-Output "Downloading fmax.war from S3"
    aws s3 cp s3://aimpoc/{{VERSION_NUMBER}}/app/fmax.war C:\{{CURRENT_VERSION}}\webapps\fmax.war --region us-east-1
    if (-not (Test-Path C:\{{CURRENT_VERSION}}\webapps\fmax.war)) {
        Write-Error "Failed to download fmax.war from S3"
        exit 1
    }
    if (Get-Service -Name {{CURRENT_VERSION}} -ErrorAction SilentlyContinue) {
        Write-Output "Starting {{CURRENT_VERSION}} service"
        Start-Service -Name {{CURRENT_VERSION}} -ErrorAction SilentlyContinue
    } else {
        Write-Error "Service {{CURRENT_VERSION}} not found"
        exit 1
    }
    Write-Output "AiM instance upgrade completed successfully"
} catch {
    Write-Error "Error upgrading AiM instance: $_"
    exit 1
}