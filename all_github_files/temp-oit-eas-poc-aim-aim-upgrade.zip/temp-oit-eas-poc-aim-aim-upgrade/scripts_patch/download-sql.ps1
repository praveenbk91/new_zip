$ErrorActionPreference = "Stop"
try {
    $targetPath = "C:\scripts\sql\{{VERSION_NUMBER}}"
    $logFile = "C:\temp\s3_download.log"
    
    New-Item -Path "C:\temp" -ItemType Directory -Force | Out-Null
    New-Item -Path $targetPath -ItemType Directory -Force | Out-Null
    Write-Output "Created $targetPath" | Out-File $logFile -Append
    
    $files = aws s3 ls s3://aimpoc/{{VERSION_NUMBER}}/sql/ --region us-east-1 | ForEach-Object {
        if ($_ -match "\s+\d+\s+(.+\.sql)$") { $Matches[1] }
    }
    if (-not $files) {
        Write-Error "No .sql files found"
        Write-Output "Error: No .sql files found in s3://aimpoc/{{VERSION_NUMBER}}/sql/" | Out-File $logFile -Append
        exit 1
    }
    
    foreach ($file in $files) {
        $fileName = Split-Path $file -Leaf
        $localFile = Join-Path $targetPath $fileName
        Write-Output "Downloading $fileName" | Out-File $logFile -Append
        aws s3 cp "s3://aimpoc/{{VERSION_NUMBER}}/sql/$fileName" "$localFile" --region us-east-1 2> "$env:TEMP\s3_error.txt"
        if (-not (Test-Path $localFile)) {
            $errorMsg = Get-Content "$env:TEMP\s3_error.txt" -Raw
            Write-Error "Failed to download $fileName. Error: $errorMsg"
            Write-Output "Error: Failed to download $fileName. Error: $errorMsg" | Out-File $logFile -Append
            exit 1
        }
    }
    
    Write-Output "Downloaded $($files.Count) .sql files to $targetPath" | Out-File $logFile -Append
} catch {
    Write-Error "Error: $_"
    Write-Output "Error: $_" | Out-File $logFile -Append
    exit 1
}