$ErrorActionPreference = "Stop"
try {
    $batFile = "C:\{{VERSION_PATH}}\Reports\Reports\UploadReports_{{VERSION_NUMBER}}.bat"
    if (-not (Test-Path $batFile)) {
        Write-Error "UploadReports_{{VERSION_NUMBER}}.bat not found at $batFile"
        exit 1
    }
    Write-Output "Configuring $batFile"
    $lines = Get-Content -Path $batFile
    $newLines = @()

    # First pass: Replace the java -jar line globally
    foreach ($line in $lines) {
        $newLine = $line
        if ($line -match '(?im)^[\s]*@REM\s+java -jar cmisclient\.jar .*?-a REPORT -ft \[FILE_TITLE\] -ri \[REPORT_ID\] -f \[FILE_PATH\] -rm \[MODULE_LIST\] -rt \[REPORT_TITLE\] -rd \[REPORT_DESCRIPTION\]') {
            $newLine = 'java -jar cmisclient.jar %OPTIONS% -a REPORT -ft [FILE_TITLE] -ri [REPORT_ID] -f [FILE_PATH] -rm [MODULE_LIST] -rt [REPORT_TITLE] -rd [REPORT_DESCRIPTION]'
            Write-Output "Matched java -jar line globally, replaced with: $newLine"
        }
        $newLines += $newLine
    }

    # Second pass: Process Oracle block
    $inOracleBlock = $false
    $tempLines = @()
    foreach ($line in $newLines) {
        $newLine = $line
        if ($line -match '(?im)^[\s]*@REM\s+Oracle:') {
            $inOracleBlock = $true
            Write-Output "Entered Oracle block at line: $line"
        } elseif ($line -match '(?im)^[\s]*@REM\s+(SQL Server|MySQL):') {
            $inOracleBlock = $false
            Write-Output "Exited Oracle block at line: $line"
        }

        if ($inOracleBlock) {
            Write-Output "Processing line in Oracle block: $line"
            if ($line -match '(?im)^[\s]*@REM\s+Oracle:') {
                $newLine = 'Oracle:'
                Write-Output "Matched Oracle: line, replaced with: $newLine"
            } elseif ($line -match '(?im)^[\s]*@REM\s+SET USER_NAME=root') {
                $newLine = 'SET USER_NAME=root'
                Write-Output "Matched USER_NAME line, replaced with: $newLine"
            } elseif ($line -match '(?im)^[\s]*@REM\s+SET U_PASSWORD=root') {
                $newLine = 'SET U_PASSWORD=root'
                Write-Output "Matched U_PASSWORD line, replaced with: $newLine"
            } elseif ($line -match '(?im)^[\s]*@REM\s+SET U_SERVER=(http://localhost:(8080|80)/fmax)') {
                $parentDir = Split-Path -Parent $batFile
                if ($parentDir -like "*prod*") {
                    $newLine = 'SET U_SERVER=http://localhost:80/fmax'
                    Write-Output "Matched U_SERVER line in prod environment, replaced with: $newLine"
                } else {
                    # Remove @REM for test environments, keep original port
                    $newLine = $line -replace '(?im)^[\s]*@REM\s+', ''
                    Write-Output "Matched U_SERVER line in non-prod environment, removed @REM, replaced with: $newLine"
                }
            } elseif ($line -match '(?im)^[\s]*@REM\s+SET U_DB=Oracle') {
                $newLine = 'SET U_DB=Oracle'
                Write-Output "Matched U_DB line, replaced with: $newLine"
            }
        }
        $tempLines += $newLine
    }
    $content = $tempLines -join "`r`n"
    $content | Set-Content -Path $batFile
    Write-Output "Configured UploadReports_{{VERSION_NUMBER}}.bat successfully"
} catch {
    Write-Error "Error configuring UploadReports_{{VERSION_NUMBER}}.bat: $_"
    exit 1
}