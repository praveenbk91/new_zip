$ErrorActionPreference = "Stop"
try {
    $batFile = "C:\{{VERSION_PATH}}\Reports\Reports\UploadReports_{{VERSION_NUMBER}}.bat"
    if (-not (Test-Path $batFile)) {
        Write-Error "UploadReports_{{VERSION_NUMBER}}.bat not found at $batFile"
        exit 1
    }
    Write-Output "Running $batFile"
    $process = Start-Process -FilePath $batFile -NoNewWindow -PassThru -Wait
    if ($process.ExitCode -ne 0) {
        Write-Error "UploadReports_{{VERSION_NUMBER}}.bat failed with exit code $($process.ExitCode)"
        exit 1
    }
    Write-Output "UploadReports_{{VERSION_NUMBER}}.bat executed successfully"
} catch {
    Write-Error "Error running UploadReports_{{VERSION_NUMBER}}.bat: $_"
    exit 1
}