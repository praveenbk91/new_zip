$ErrorActionPreference = "Stop"
try {
    $s3Path = "s3://aimpoc/{{VERSION_NUMBER}}/Reports/"
    $destPath = "C:\{{VERSION_PATH}}\Reports"
    if (-not (Test-Path "C:\{{VERSION_PATH}}\")) {
        Write-Error "Parent destination path C:\{{VERSION_PATH}} does not exist"
        exit 1
    }
    if (-not (Test-Path $destPath)) {
        New-Item -Path $destPath -ItemType Directory -Force | Out-Null
        Write-Output "Created destination directory $destPath"
    }
    Write-Output "Downloading reports from $s3Path to $destPath"
    aws s3 sync $s3Path $destPath --region us-east-1
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to download reports from $s3Path"
        exit 1
    }
    Write-Output "Reports downloaded successfully"
} catch {
    Write-Error "Error downloading reports: $_"
    exit 1
}